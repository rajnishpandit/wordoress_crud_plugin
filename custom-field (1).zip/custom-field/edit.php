<?php
  $id = $_GET['id'];
  global $wpdb;
  global $table_perfix;
  $table=$table_perfix.'form_data';
  $sql = "SELECT * FROM $table WHERE id = $id";
  $result = $wpdb->get_results($sql);
  //print_r($result);die();
  foreach($result as $list){
     $size = $list->size;
     $id = $list->id;
  }
?>
<form action="" class="form-container" method="post">
    <h1>Add Size</h1>

    <input type="radio" id="small" name="size" value="<?php echo $size; ?>">
    <label for="small">Small</label><br>
    <input type="radio" id="midium" name="size" value="<?php echo $size; ?>">
    <label for="nidium">Midium</label><br>
    <input type="radio" id="large" name="size" value="<?php echo $size; ?>">
    <label for="large">Large</label>

    <button type="submit" class="btn" name="update" value="<?php echo $id; ?>">Update</button>

  </form>
  <?php
  global $wpdb;
  global $table_perfix;
  $table=$table_perfix.'form_data';
  $sql = "SELECT * FROM $table";
  $result = $wpdb->get_results($sql);
  foreach($result as $list){
     $size = $list->size;
     $id = $list->id;
  $size1 = $_POST['size'];
  if(isset($_POST['update'])){
  $data = array(
                 //'tittle' => "hiiiiii",
                 //'message' => "hello",
                 //'color' => 
                 'size' => $size1
               );
  $wherecondition = array(
                 'id' => $id
               );

  $updated = $wpdb->update( $table, $data, $wherecondition );
  print_r($updated);
  }
}
?>