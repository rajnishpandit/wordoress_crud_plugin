<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Countdown Timer</title>
   <style>
    body{margin:0; padding: 0;}
    .main {
    display: flex;
    background-color: #000;
    align-items: center;
    justify-content: center;
    color:#fff;
}
.main .countMine {
    border: 1px solid #6a6666;
    padding: 0 13px;
    font-weight: 500;
    font-size: 15px;
        margin-right: 25px;
}
.main .product p {
    border: 1px solid #6a6666;
    font-size: 12px;
    padding-right: 80px;
    margin-right: 25px;
}
.main .product p span {
    background-color: #e70029;
    padding-left: 13px;
    padding-right: 13px;
}
.main .customized {
    font-size: 11px;
}
</style>
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script type="text/javascript">
    function setCookie(cname, cvalue) {
      const d = new Date();
      d.setTime(d.getTime() + (24 * 24 * 60 * 60 * 1000));
      let expires = "expires="+d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    function getCookie(cname) {
      let name = cname + "=";
      let ca = document.cookie.split(';');
      for(let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
      c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
      }
      }
      return "";
    }

    $(document).ready(function(){
      var checkNumber = getCookie('inventory');
      if(checkNumber == '' || checkNumber == undefined || checkNumber == NaN
     ){
        var num = 7013777;
        var formattedNum = num.toLocaleString();
        $('.countMine').html(formattedNum);
      }else{
        $('.countMine').html(parseInt(checkNumber));
      } 
      setInterval(function(){
        var checkNumber = getCookie('inventory');
        if(checkNumber == '' || checkNumber == undefined || checkNumber == NaN){
          var a = parseInt($('.countMine').attr('count'));
        }else{
          var a = parseInt(checkNumber);
        }
        a = a + 1;
        setCookie('inventory', a);
        var tt = a.toLocaleString("en-US");
        $('.countMine').html(tt);
      }, 12000);
    });
  </script>-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script type="text/javascript">

    $(document).ready(function(){
        
        var checkNum = '';
    var itemcounts = sessionStorage.getItem("countsee");
    if(itemcounts != '' && itemcounts != 'NaN' && itemcounts != undefined){
        checkNum = parseInt(itemcounts) + parseInt(1);
        var formatnum = checkNum.toLocaleString("en-US");
        setTimeout(function(){
           var num = $('.countMine').text(formatnum);
			// var formattedNum = num.toLocaleString();
			// var tt = num.toLocaleString("en-US");
        }, 1000);
          
    }else{
        $('.countMine').text('7013777');
      checkNum = 7013777;
    }
      
    //  alert(checkNum);
      setInterval(function(){
         // a = checkNum + 1;
        var aa =  checkNum++;
      //    alert(aa);
      
      sessionStorage.setItem("countsee", aa);
      $('.countMine').text(aa);
      
        
      }, 6000);
      
    });
  </script>
</head>
<body>
  <div class="main">
  <div class="product">
    <p class="product1"><span>ONE JERSEY EVERY 12</span> SECONDS</p>
  </div>
  <div class="countMine" count="7013777"></div>
  <div class="customized">
    <p class="customized1">CUSTOMIZED</p>
  </div>
</div>
</body>
</html>
