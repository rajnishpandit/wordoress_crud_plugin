<?php
    $siteurl = site_url();
	$url = $_SERVER['REQUEST_URI'];
	$mine = $_REQUEST['enc'];
	$decoded_data2 = base64_decode($mine);
	if (strpos($url, '?enc=') !== false) {
		echo "<script>setTimeout(function(){ window.location.replace('".$decoded_data2."'); }, 100);</script>";
	}
// 	if($_COOKIE['redirectUrl'] != ''){
//         $mine = $_COOKIE['redirectUrl'];
//         $decoded_data2 = base64_decode($mine);
//         setcookie("redirectUrl", '');
//     	echo "<script>setTimeout(function(){ window.location.replace('".$decoded_data2."');}, 100);</script>";
//     }
		
// 	if (strpos($url, '?redirectLink=') !== false) {
// 	    $mine = $_REQUEST['redirectLink'];
// 	    $decoded_data2 = base64_decode($mine);
// 		echo "<script>setTimeout(function(){ window.location.replace('".$decoded_data2."');}, 4000);</script>";
// 	}
?>