<?php
/**
* Plugin Name: encryption-plugin
* Plugin URI: https://indybytes.com/
* Description: This plugin created for custom field.
* Version: 0.1
* Author: Indybytes
* Author URI: https://indybytes.com/
**/
function test_contact_form() {      
        global $wpdb; 

    require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );

    $db_table_name = $wpdb->prefix . 'encryption';  // table name
    if( $wpdb->get_var( "SHOW TABLES LIKE '$db_table_name'" ) != $db_table_name ) {
        if ( ! empty( $wpdb->charset ) )
            $charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
        if ( ! empty( $wpdb->collate ) )
            $charset_collate .= " COLLATE $wpdb->collate"; 
        $sql = "CREATE TABLE " . $db_table_name . " (
            id int(11) NOT NULL auto_increment,
                        title varchar(500) NOT NULL,
                        link varchar(500) NOT NULL,
                        lastlink varchar(500) NOT NULL,
                        redirectlink varchar(500) NOT NULL,
                        customlink varchar(500) NOT NULL,
                        PRIMARY KEY (id) 
        ) $charset_collate;";


dbDelta($sql); // create query 
        }  
    }
    register_activation_hook(__FILE__, 'test_contact_form');



register_deactivation_hook( __FILE__, 'my_plugins_deactivate' );
function my_plugins_deactivate() {
	global $wpdb;
	$db_table_name = $wpdb->prefix . 'encryption';
  //$sql="DROP TABLE $db_table_name";
  //$wpdb->query($sql);
	}

	register_uninstall_hook( __FILE__, 'my_plugins_uninstall' );
function my_plugins_uninstall() {
	global $wpdb;
	$db_table_name = $wpdb->prefix . 'encryption';
  $sql="DROP TABLE $db_table_name";
  $wpdb->query($sql);
	}


add_action('admin_menu','encryption_menu');
function encryption_menu(){
	
add_menu_page('encryption','encryption',8,__FILE__,'encryption_list');
}
add_shortcode('encryption_script', 'encryption_script');

 
function encryption_list(){
	include('encryption_list.php');
}

function encryption_script(){
	include('inject.php');
}

?>
