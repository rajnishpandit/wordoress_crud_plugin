<?php
  global $wpdb;
  global $table_perfix;
  $table=$table_perfix.'form_data';
  $sql = "SELECT * FROM $table";
  $result = $wpdb->get_results($sql);
    foreach($result as $list){
     $id = $list->id;
  }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
</head>
<body><br>
<button class="open-button" onclick="openForm()">Open Text Form</button>
<div class="form-popup text form-popup1" id="myForm">
  <form action="" class="form-container" method="post">
    <h1>Add Text</h1>

    <label for="title"><b>Title</b></label>
    <input type="text" value="" name="textfield" class="textfield" required>

    <label for="message"><b>Message</b></label>
    <input type="text" value="" name="message" class="message" required>

    <input type="hidden" name="text" value="text">

    <button type="submit" id="btn0" class="btn" name="submit">save</button>
    <button type="submit" id="btn1" class="btn update" name="update" value="">update</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
  document.getElementById("btn0").style.display = "block";
  document.getElementById("btn1").style.display = "none";
  document.getElementById("myForm1").style.display = "none";
  document.getElementById("myForm2").style.display = "none";
}

function openeditform() {
  document.getElementById("btn1").style.display = "none";
  document.getElementById("myForm").style.display = "none";
  document.getElementById("myForm1").style.display = "none";
  document.getElementById("myForm2").style.display = "none";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>


<!--2nd form-->
<button class="open-button open-button1" onclick="openForm1()">Open CheckBox Form</button>

<div class="form-popup checkbox form-popup2" id="myForm1">
  <form action="" class="form-container" method="post">
    <h1>Add Color</h1>

    <table border="1">  
   <tr>  
      <td>Red</td>  
      <td><input type="checkbox" name="techno[]" class="color" value="Red"></td>  
   </tr>  
   <tr>  
      <td>Yellow</td>  
      <td><input type="checkbox" name="techno[]" class="color" value="Yellow"></td>  
   </tr>  
   <tr>  
      <td>Blue</td>  
      <td><input type="checkbox" name="techno[]" class="color" value="Blue"></td>  
   </tr>  
   <tr>  
      <td>Green</td>  
      <td><input type="checkbox" name="techno[]" class="color" value="Green"></td>
      <input type="hidden" name="text" value="checkbox">  
   </tr>  
   <tr>  
      <td colspan="2" align="center">
        <button type="submit" id="btncolor" class="btn" name="submit1">save</button>
        <button type="submit" id="btn1" class="btn update" name="update" value="">update</button>
        <button type="button" class="btn cancel" onclick="closeForm1()">Close</button>
      </td>  
   </tr>  
</table>  
  </form>
</div>

<script>
function openForm1() {
  document.getElementById("myForm1").style.display = "block";
  document.getElementById("btncolor").style.display = "block";
  document.getElementById("btn1").style.display = "none";
  document.getElementById("myForm2").style.display = "none";
  document.getElementById("myForm").style.display = "none";
}

function closeForm1() {
  document.getElementById("myForm1").style.display = "none";
}
</script>

<!--3rd form-->
<button class="open-button open-button2" onclick="openForm2()">Open Radio Form</button>

<div class="form-popup radio form-popup3" id="myForm2">
  <form action="" class="form-container" method="post">
    <h1>Add Size</h1>

    <input type="radio" id="small" name="size" class="size" value="small">
    <label for="small">Small</label><br>
    <input type="radio" id="midium" name="size" class="size" value="midium">
    <label for="nidium">Midium</label><br>
    <input type="radio" id="large" name="size" class="size" value="large">
    <label for="large">Large</label>
    <input type="hidden" name="text" value="radio">

    <button type="submit" id="btnsize" class="btn" name="submit2">save</button>
    <button type="submit" id="btn1" class="btn update" name="update" value="">update</button>
    <button type="button" class="btn cancel" onclick="closeForm2()">Close</button>
  </form>
</div><br><br>

<script>
function openForm2() {
  document.getElementById("myForm2").style.display = "block";
  document.getElementById("btnsize").style.display = "block";
  document.getElementById("btn1").style.display = "none";
  document.getElementById("myForm1").style.display = "none";
  document.getElementById("myForm").style.display = "none";
}



function closeForm2() {
  document.getElementById("myForm2").style.display = "none";
}
</script>
</body>
</html>

<?php
$size = $_POST['size'];
if(isset($_POST['submit'])){    
	$message=$_POST['message'];
	$tittle=$_POST['textfield'];  
  $text=$_POST['text'];   
  $wpdb->insert($table, array('tittle' => $tittle, 'message' => $message, 'formname1' => $text)); 
} 


if(isset($_POST['submit1'])){ 
  $text=$_POST['text'];  
  $checkbox1=$_POST['techno'];
  $checkbox3="";
  foreach($checkbox1 as $checkbox2){
    $checkbox3.=$checkbox2.",";
  }     
  $wpdb->insert($table, array('color' => $checkbox3, 'formname1' => $text)); 
} 


if(isset($_POST['submit2'])){  
  $size=$_POST['size'];
  $text=$_POST['text'];    
  $wpdb->insert($table, array('size' => $size, 'formname1' => $text)); 
} 



  if(isset($_POST['delete'])){
  $wpdb->delete( $table, array( 'id' => $_POST['delete'] ) );
  }

  if(isset($_POST['update'])){
  $message=$_POST['message'];
  $tittle=$_POST['textfield'];
  $size=$_POST['size'];
  $checkbox1=$_POST['techno'];
  $checkbox3="";
  foreach($checkbox1 as $checkbox2){
    $checkbox3.=$checkbox2.",";
  }
  $data = array(
                 'tittle' => $tittle,
                 'message' => $message,
                 'size' => $size,
                 'color' => $checkbox3,
               );
  $wherecondition = array(
                 'id' => $_POST['update']
               );
  $updated = $wpdb->update( $table, $data, $wherecondition );
  }


  $sql="SELECT * FROM $table";
  $result=$wpdb->get_results($sql);
?>
<table border="1">
  <?php
    foreach($result as $list){
     $id = $list->id;
  ?>

  <tr>
    <td><?php echo $list->tittle ?></td>
    <td><?php echo $list->message ?></td>
    <td><?php echo $list->color ?></td>
    <td><?php echo $list->size ?></td>
    <form action="" method="post">
    <td><a href="javascript:void(0)" class="edit" id="edit" value="<?php echo $id; ?>" formname="<?php echo $list->formname1 ?>" title="<?php echo $list->tittle ?>" message="<?php echo $list->message ?>" color="<?php echo $list->color ?>" size="<?php echo $list->size ?>" name="edit" onclick="openeditform()">EDIT</a></td>
    <td><button name="delete" value="<?php echo $id; ?>">DELETE</button></td>
    </form>
  </tr>

  <?php }
  ?>
</table>
<script>
jQuery(document).ready(function(){
  jQuery(".edit").click(function(e){
    e.preventDefault();
  var formName = jQuery(this).attr("formname");
    jQuery("."+formName).show();

    jQuery("#btn0").hide();
    jQuery("#btncolor").hide();
    jQuery("#btnsize").hide();
    jQuery("#btn1").show();

  var tittle = jQuery(this).attr("title");
   jQuery(".textfield").val(tittle);

  var message = jQuery(this).attr("message");
   jQuery(".message").val(message);
  if(formName == 'checkbox'){
  var color = jQuery(this).attr("color");
  color = color.split(',');
  var arraylength = color.length;
  jQuery('.color').prop('checked', false);
  for(var a = 0; a < arraylength; a++){
    jQuery('.color[value="'+color[a]+'"]').prop('checked', true);
  }
  }

  if(formName == 'radio'){
    var color = jQuery(this).attr("size");
    jQuery('.size[value="'+color+'"]').prop('checked', true);
  }
   
  
  // jQuery('.cancel').click(function(e) { return false; })
 var id = jQuery(this).attr("value");
   jQuery(".update").val(id);

  });
});

/*jQuery(document).ready(function(){
jQuery(".open-button1").click(function(){
jQuery(".form-popup1").hide();
jQuery(".form-popup3").hide();

});
});

jQuery(document).ready(function(){
jQuery(".open-button2").click(function(){
jQuery(".form-popup1").hide();
jQuery(".form-popup2").hide();
});
});

jQuery(document).ready(function(){
jQuery(".open-button").click(function(){
jQuery(".form-popup2").hide();
jQuery(".form-popup3").hide();
});
});*/

</script>


