<?php
add_shortcode('datainsert','datainsert');
function datainsert(){
if(isset($_POST['submit'])){  
    global $wpdb;
	global $table_perfix;
	$table=$table_perfix.'form_data';  
	$message=$_POST['message'];
	$tittle=$_POST['textfield'];     
    $wpdb->insert($table_name, array('tittle' => $tittle, 'message' => $message, 'content_date' => $date)); 
} 
}
?>