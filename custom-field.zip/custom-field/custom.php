<?php
/**
* Plugin Name: custom-field-plugin
* Plugin URI: http://localhost/rajnish/wordpress/
* Description: This plugin created for custom field.
* Version: 0.1
* Author: Rajnish Sharma
* Author URI: http://localhost/rajnish/wordpress/
**/
register_activation_hook( __FILE__, 'my_plugin_activate' );
function my_plugin_activate() {
	global $wpdb;
	global $table_perfix;
	$table=$table_perfix.'form_data';

	$sql="CREATE TABLE $table (
  `id` int(20) NOT NULL,
  `tittle` varchar(256) NOT NULL,
  `message` varchar(500) NOT NULL,
  `color` varchar(500) NOT NULL,
  `size` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;ALTER TABLE $table
  ADD PRIMARY KEY (`id`);ALTER TABLE $table
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;
COMMIT;";
 $wpdb->query($sql);
	}


register_deactivation_hook( __FILE__, 'my_plugin_deactivate' );
function my_plugin_deactivate() {
	global $wpdb;
	global $table_perfix;
	$table=$table_perfix.'form_data';
    $sql="DROP TABLE $table";
    $wpdb->query($sql);
	}


add_action('admin_menu','form_data_menu');
function form_data_menu(){
	
add_menu_page('Form Data','Form Data',8,__FILE__,'form_data_list');
}
add_shortcode('form_data_list', 'form_data_list');

function form_data_list(){
	include('form_data_list.php');
	}

?>
