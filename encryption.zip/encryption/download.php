<?php
 global $wpdb;
  $db_table_name = $wpdb->prefix . 'encryption';
  $sql = "SELECT * FROM $db_table_name";
  $data = $wpdb->get_results($sql);
  foreach($data as $row1) {
  

 $filename = 'person.csv';

// open csv file for writing
$f = fopen($filename, 'w');


if ($f === false) {
	die('Error opening the file ' . $filename);
}

// write each row at a time to a file
foreach ($row1 as $row) {
	 fputcsv($f, $row);
}

// close the file
fclose($f);
}
?>