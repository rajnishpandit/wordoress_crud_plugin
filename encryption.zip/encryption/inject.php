<?php
	$url = $_SERVER['REQUEST_URI'];
	if (strpos($url, '?encrypt=') !== false) {
		$mine = $_REQUEST['encrypt'];
		$encoded_data1 = $mine;
		$decoded_data2 = base64_decode($encoded_data1);
		echo "<script>window.location.replace('".$decoded_data2."');</script>";
	}
?>