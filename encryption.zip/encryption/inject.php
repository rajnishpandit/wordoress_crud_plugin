<?php
// echo '<script>function setCookie(cname, cvalue) {const d = new Date(); d.setTime(d.getTime() + (24 * 24 * 60 * 60 * 1000)); let expires = "expires="+d.toUTCString(); document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";} function getCookie(cname) {let name = cname + "=";let ca = document.cookie.split(";");for(let i = 0; i < ca.length; i++) {let c = ca[i];while (c.charAt(0) == " ") {c = c.substring(1);}if (c.indexOf(name) == 0) {return c.substring(name.length, c.length);}}return "";}</script>';
    $siteurl = site_url();
	$url = $_SERVER['REQUEST_URI'];
	$mine = $_REQUEST['enc'];
	if (strpos($url, '?enc=') !== false) {
		$siteurl = site_url();
		setcookie("redirectUrl", $mine);
		echo "<script>setTimeout(function(){ window.location.replace('".$siteurl."'); }, 1000);</script>";
	}
	if($_COOKIE['redirectUrl'] != ''){
        $mine = $_COOKIE['redirectUrl'];
        $decoded_data2 = base64_decode($mine);
        setcookie("redirectUrl", '');
    	echo "<script>setTimeout(function(){ window.location.replace('".$decoded_data2."');}, 2000);</script>";
    }
		
// 	if (strpos($url, '?redirectLink=') !== false) {
// 	    $mine = $_REQUEST['redirectLink'];
// 	    $decoded_data2 = base64_decode($mine);
// 		echo "<script>setTimeout(function(){ window.location.replace('".$decoded_data2."');}, 4000);</script>";
// 	}
?>