<?php
//database variables
  global $wpdb;
  $db_table_name = $wpdb->prefix . 'encryption';
  //$table=$table_perfix.'encryption';
  $sql = "SELECT * FROM $db_table_name";
  $result = $wpdb->get_results($sql);
    foreach($result as $list){
     $id = $list->id;
  }

  $a = plugin_dir_url( __FILE__ );
  $plugin_url = $a.'persons.csv';
?>

<!-- form-->
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
  .button {
    display: block;
    width: 115px;
    height: 25px;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    line-height: 25px;
}
a.download.button {
    background-color: #00b74a;
    width: 15%;
}
.encryptbutton{
  background-color: #f93154;
}

.deletebutton{
  background-color: #f93154;
}
  </style>
<body><br>
  <form action="" class="form-container" method="post">
    <label for="link"><b>Link</b></label>
    <input type="text" value="" name="link" class="link" required>

    <label for="title"><b>Title</b></label>
    <input type="text" value="" name="title" class="title" required>

    <button class="encryptbutton" type="submit" id="btn0" class="btn" name="submit">ENCRYPT</button>
    <br><br>
  </form>

<form action="" class="form-container" method="post">
<a href="<?php echo $plugin_url; ?>" name="download" class="download button" download>DOWNLOAD Csv</a>
<input type="submit" name="dwn" value="Create Csv" class="download button">
</form>
<?php


if(isset($_POST['dwn'])){
$sql = "SELECT * FROM $db_table_name";
$result = $wpdb->get_results($sql);
$a = plugin_dir_url( __FILE__ );
$plugin_url = $a.'persons.csv';
$plugin_dir = plugin_dir_path( __FILE__ );
$filenames = $plugin_dir.'persons.csv';
$fp = fopen($filenames, 'w');
// Loop through file pointer and a line
foreach ($result as $fields) {
  $array = (array) $fields;
    $link = $array["link"];
    fputcsv($fp, $array);
}
  $plugin_dir = plugin_dir_path( __FILE__ );
  $url = $plugin_dir.'persons.csv';
  $file_name = basename($url);
  $info = pathinfo($file_name);
  if ($info["extension"] == "csv") {
    if(file_put_contents( $file_name, 
            file_get_contents($url))) { 
        echo "File save successfully next download by download button";
    }
    else { 
        echo "File downloading failed."; 
    }
  }
fclose($fp);
}


// action on submit and podt filed data
if(isset($_POST['submit'])){    
  $link=$_POST['link'];
  $title=$_POST['title'];
  $url=site_url();
  $custom_link=$url.''.'/'.$title;
  $data = $link;
  $search_terms = "OpenAI GPT-3";
  //$data1 = $link.''.'?shop'.'='.$url;
  $encoded_data = base64_encode($data);
  $b = $url.''.'?enc=~'.$encoded_data.'~';

  //insert query
  $wpdb->insert($db_table_name, array('title' => $title, 'link' => $link, 'lastlink' => $encoded_data, 'redirectlink' => $b, 'customlink' => $custom_link)); 
} 


//Delete query
  if(isset($_POST['delete'])){
  $wpdb->delete( $db_table_name, array( 'id' => $_POST['delete'] ) );
  }

  $sql="SELECT * FROM $db_table_name";
  $result=$wpdb->get_results($sql);
?>

<!-- Fetch filed data in the table -->
<table border="1">
  <tr><th>Link</th>
      <th>Encrypt Link</th>
      <th>Title</th>
      <th>Action</th>
  </tr>
  <?php
    foreach($result as $list){
     $links = $list->link;
     $redirectlink = $list->redirectlink;
  ?>
  <tr>
    <td><?php echo $list->link ?></td>
    <td><a href="<?php echo $redirectlink; ?>"><?php echo $redirectlink; ?></a></td>
    <td><?php echo $list->title ?></td>
    <form action="" method="post">
    <td><button class="deletebutton" name="delete" value="<?php echo $id; ?>">DELETE LINK</button></td>
    </form>
  </tr>
  <?php }
  ?>
</table>

 



